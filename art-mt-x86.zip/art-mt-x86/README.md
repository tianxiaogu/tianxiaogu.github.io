# Install

DANGEROUS OPERATION!!!

Make sure you know what you are doing.

1. Start your emulator with `-writable-system`
2. If you have connected to multiple emulators or devices, you should probably set the device id, e.g., `adb -s emulator-5554`.
3. Read `install_libart.sh` before you run it.
4. Run `install_libart.sh`.
