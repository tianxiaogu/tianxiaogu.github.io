# README


## Install


    adb push ape.jar /sdcard/


## Run

We provide a python script (i.e., `ape.py`) to facilitate running Ape on Android devices.

The following command starts to run Ape to test the Calculator on a real device connected via `adb`.


    ./ape.py -p com.google.android.calculator --running-minutes 100 --ape sata


Check the `ape.py` if you want to run Ape with an emulator.
You should at least remove the `-d` options for `adb`.

Options:

* `-p`: specify the package name, the same as Monkey
* `--running-minutes`: the total testing time in minutes
* `--ape sata`: use the default exploration strategy described in the paper.
    * You can also try `orbit`, `wechat`, `random`

