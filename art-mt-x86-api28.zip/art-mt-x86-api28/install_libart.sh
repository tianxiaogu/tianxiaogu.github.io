#! /bin/bash

ADB=$(which adb)

SERIAL=${SERIAL:-emulator-5554}

if [[ "x$ADB" == "x"  ]];
then
    echo "No adb in $PATH"
    exit 1
fi

DIR=$(pushd "$(dirname "$BASH_SOURCE[0]")" > /dev/null && pwd && popd > /dev/null )


REMOTE_TMP=${REMOTE_TMP:-/sdcard}

install_lib() {
 echo "Push..."
 $ADB -s $SERIAL push "${DIR}/lib/$LIB_FILE" $REMOTE_TMP/$LIB_FILE
 if [[ $? != 0 ]]; then
     exit 1
 fi

 echo "Backup..."
 $ADB -s $SERIAL shell su root cp /system/lib/$LIB_FILE $REMOTE_TMP/$LIB_FILE.backup
 if [[ $? != 0 ]]; then
     exit 1
 fi

 echo "Pull backup..."
 $ADB -s $SERIAL pull $REMOTE_TMP/$LIB_FILE.backup ${DIR}
 if [[ $? != 0 ]]; then
     exit 1
 fi

 echo "Copy..."
 $ADB -s $SERIAL shell su root cp $REMOTE_TMP/$LIB_FILE /system/lib/$LIB_FILE
 if [[ $? != 0 ]]; then
     exit 1
 fi

 echo "Chmod..."
 $ADB -s $SERIAL shell su root chmod 644 /system/lib/$LIB_FILE
 if [[ $? != 0 ]]; then
     exit 1
 fi

 echo "Chown..."
 $ADB -s $SERIAL shell su root chown root:root /system/lib/$LIB_FILE
 if [[ $? != 0 ]]; then
     exit 1
 fi
}



$ADB -s $SERIAL root | grep "restarting adbd as root"
if [[ $? == 0 ]]; then
    echo "Wait 2 seconds for restarting adb as root"
    sleep 2
fi
$ADB -s $SERIAL ls $REMOTE_TMP
if [[ $? != 0 ]]
then
    echo "Device $SERIAL is offline or there is no $REMOTE_TMP."
    exit
fi

$ADB -s $SERIAL shell su root mount -o remount,rw /

if [[ $? != 0 ]];
then
    echo "Cannot alter / to writable"
    echo "Make sure emulator is started with option '-writable-system'"
    exit 1
fi

LIBS=(libart.so libart-compiler.so libart-dexlayout.so libdexfile.so)

for LIB in ${LIBS[@]}
do
    LIB_FILE=$LIB
    install_lib
done

$ADB -s $SERIAL shell su root reboot


